@javax.xml.bind.annotation.XmlSchema(namespace = "http://autoCheck", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package autocheck;
