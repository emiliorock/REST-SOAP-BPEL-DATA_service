@javax.xml.bind.annotation.XmlSchema(namespace = "http://soacourse.unsw.edu.au/dldefinitions", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package au.edu.unsw.soacourse.dldefinitions;
